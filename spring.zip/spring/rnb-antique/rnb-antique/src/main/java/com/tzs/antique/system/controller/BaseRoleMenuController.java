package com.tzs.antique.system.controller;


import org.springframework.web.bind.annotation.RequestMapping;

    import org.springframework.web.bind.annotation.RestController;

/**
* @author YHS
*/
    @RestController
@RequestMapping("//base-role-menu")
        public class BaseRoleMenuController {

    }
