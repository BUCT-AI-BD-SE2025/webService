package com.tzs.antique.common.enums;

public enum LimitType {
    // 传统类型
    CUSTOMER,
    // 根据 IP 限制
    IP ;
}
