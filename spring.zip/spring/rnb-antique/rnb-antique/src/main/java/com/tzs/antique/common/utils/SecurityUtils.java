package com.tzs.antique.common.utils;
//
//public class SecurityUtils extends org.apache.shiro.SecurityUtils {
////    public SecurityUtils() {
////        super();
////    }
//
//}
