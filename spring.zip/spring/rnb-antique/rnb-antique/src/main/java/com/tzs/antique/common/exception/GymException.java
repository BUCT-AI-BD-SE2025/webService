package com.tzs.antique.common.exception;

/**
 *  系统内部异常
 */
public class GymException extends Exception {

    private static final long serialVersionUID = -99496276656565441L;

    public GymException(String message) {
        super(message);
    }

}
