package com.tzs.antique.system.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.tzs.antique.system.entity.BaseRole;
import org.apache.ibatis.annotations.Mapper;

/**
* @author YHS
*/
    @Mapper
    public interface BaseRoleMapper extends BaseMapper<BaseRole> {

    }
