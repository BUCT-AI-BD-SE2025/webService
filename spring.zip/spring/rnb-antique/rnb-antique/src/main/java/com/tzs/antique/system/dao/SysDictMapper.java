package com.tzs.antique.system.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.tzs.antique.system.entity.SysDict;
import org.apache.ibatis.annotations.Mapper;

/**
* @author ZHZ
*/
    @Mapper
    public interface SysDictMapper extends BaseMapper<SysDict> {

    }
