package com.tzs.antique.system.service;

import com.tzs.antique.system.entity.SysDict;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author ZHZ
*/
    public interface ISysDictService extends IService<SysDict> {

    }
